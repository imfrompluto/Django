from django.shortcuts import render
from django.shortcuts import render
from .models import *
# Create your views here.

def index(request):
    context = {
        "posts":Post.objects.all(),
    }
    return render(request, 'assistant/index.html', context)
    

def post(request):
    print(request.GET.get("id"))
    postID = request.GET.get("id")
    post = Post.objects.get(id = postID)
    print(post)
    context = {
        "post":post,
    }
    return render(request, 'assistant/post.html', context)