let menu = document.getElementById("menu")
menu.onclick =function () {
    console.log("menu")
}
