from django.db import models

# Create your models here.
class Post(models.Model):
    post_header = models.CharField(max_length=200)
    post_category = models.CharField(max_length=200)
    image = models.ImageField(upload_to='images/')
    secondimage = models.ImageField(upload_to='images/')
    post_text = models.TextField(blank=True, null=True)